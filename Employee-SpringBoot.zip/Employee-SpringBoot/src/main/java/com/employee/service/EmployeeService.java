package com.employee.service;

import java.util.List;

import com.employee.model.EmployeeInfo;

public interface EmployeeService {

	public EmployeeInfo saveEmployeeInfo(EmployeeInfo employeeinfo);

	public List<EmployeeInfo> fetchEmployeeInfo();

	public EmployeeInfo fetchEmployeeInfoById(Long employeeid);


	public void deleteEmployeeInfoById(Long employeeid);

	
	

	

	

}
