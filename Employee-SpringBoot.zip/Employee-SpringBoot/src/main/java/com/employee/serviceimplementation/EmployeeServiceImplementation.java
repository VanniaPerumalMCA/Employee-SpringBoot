package com.employee.serviceimplementation;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.employee.model.EmployeeInfo;
import com.employee.repository.EmployeeRepository;
import com.employee.service.EmployeeService;

@Service
public class EmployeeServiceImplementation implements EmployeeService{
	
	
	
	@Autowired
	public EmployeeRepository employeerepository;

	@Override
	public EmployeeInfo saveEmployeeInfo(EmployeeInfo employeeinfo) {
		
		return employeerepository.save(employeeinfo);
	}

	@Override
	public List<EmployeeInfo> fetchEmployeeInfo() {
		
		return employeerepository.findAll();
	}

	@Override
	public EmployeeInfo fetchEmployeeInfoById(Long employeeid) {
		
		return employeerepository.findById(employeeid).get();
	}

	@Override
	public void deleteEmployeeInfoById(Long employeeid) {
		employeerepository.deleteById(employeeid);		
	}

	

}
