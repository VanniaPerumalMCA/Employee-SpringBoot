package com.employee.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;



@Entity
//@Data-It helps to reduce boilerplate code(lambok).
public class EmployeeInfo {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "Employee_Id")
	private Long employeeid;
	@Column(name = "Employee_Name")
	@NotBlank(message = "Please Add Employee Name")    //Using NotBlank Validation Annotations
	private String employeename;
	@Column(name = "Employee_Address")
	private String employeeaddress;
	@Column(name = "Employee_Salary")
	private int employeesalary;
	
	
	public EmployeeInfo() {
		super();
	}
	public EmployeeInfo(Long employeeid, String employeename, String employeeaddress, int employeesalary) {
		super();
		this.employeeid = employeeid;
		this.employeename = employeename;
		this.employeeaddress = employeeaddress;
		this.employeesalary = employeesalary;
	}
	public Long getEmployeeid() {
		return employeeid;
	}
	public void setEmployeeid(Long employeeid) {
		this.employeeid = employeeid;
	}
	public String getEmployeename() {
		return employeename;
	}
	public void setEmployeename(String employeename) {
		this.employeename = employeename;
	}
	public String getEmployeeaddress() {
		return employeeaddress;
	}
	public void setEmployeeaddress(String employeeaddress) {
		this.employeeaddress = employeeaddress;
	}
	public int getEmployeesalary() {
		return employeesalary;
	}
	public void setEmployeesalary(int employeesalary) {
		this.employeesalary = employeesalary;
	}
	
	
	
	

}
