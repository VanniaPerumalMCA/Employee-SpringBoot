package com.employee.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.employee.model.EmployeeInfo;
import com.employee.service.EmployeeService;

@RestController       
@RequestMapping("/Employee")
public class EmployeeController {
	@Autowired
	public EmployeeService employeeservice;
	
	// post the values to database
	@PostMapping("/save")
	public EmployeeInfo saveEmployeeInfo(@Valid @RequestBody EmployeeInfo employeeinfo)
	{
		
		return employeeservice.saveEmployeeInfo(employeeinfo);
		
	}

	// get values from database
	@GetMapping("/fetch")
	public List<EmployeeInfo> retrieveEmployeeInfo()
	{
		return employeeservice.fetchEmployeeInfo();
	}
	
	// get values from database by id
	@GetMapping("/fetch/{id}")
	public EmployeeInfo retrieveEmployeeInfoById(@PathVariable("id") Long employeeid)
	{
		return employeeservice.fetchEmployeeInfoById(employeeid);
		
	}
	
	//delete values from database by id
	@DeleteMapping("/delete/{id}")
	public String deleteEmployeeInfo(@PathVariable("id") Long employeeid)
	{
		employeeservice.deleteEmployeeInfoById(employeeid);
		return "EmployeeInfo Record Deleted Successfully";
		
	}
	

}
